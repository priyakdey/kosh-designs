export function FixedDeposits() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Fixed Deposits</h1>
      <p className="text-gray-500 dark:text-gray-400 mt-2">
        Track your fixed deposit investments.
      </p>
    </div>
  );
}
