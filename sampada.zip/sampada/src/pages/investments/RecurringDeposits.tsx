export function RecurringDeposits() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Recurring Deposits</h1>
      <p className="text-gray-500 dark:text-gray-400 mt-2">
        Track your recurring deposit investments.
      </p>
    </div>
  );
}
