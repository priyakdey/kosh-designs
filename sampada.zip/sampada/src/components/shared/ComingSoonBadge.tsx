export function ComingSoonBadge() {
  return (
    <span className="inline-flex items-center whitespace-nowrap text-[10px] font-medium text-gray-500 dark:text-gray-400 bg-gray-200 dark:bg-gray-700 px-1.5 py-0.5 rounded-full leading-none">
      Coming Soon
    </span>
  );
}
